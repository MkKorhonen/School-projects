public class Hirsipuu{
	
	
	public boolean arvaa( charecter merkki){
		
		
	}
	
	public List<Character> arvaukset(){
		
	}
	
	
	public int arvauksiaOnJaljella(){
		
		
	}
	
	public String sana(){
		
		
	}
	
	public boolean onLoppu(){
		
		
	}