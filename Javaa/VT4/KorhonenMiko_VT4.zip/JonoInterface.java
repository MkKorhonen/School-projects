public interface JonoInterface <E> {
	public void lisaaElementti(E e);
		
		
	
	public E palautaElementti();
		
		
	
	public boolean onkoJonoTyhja();
		
	
	
	public boolean onkoJonoOlemassa();
		
}
	
	
	
	
	
		
	
	
	